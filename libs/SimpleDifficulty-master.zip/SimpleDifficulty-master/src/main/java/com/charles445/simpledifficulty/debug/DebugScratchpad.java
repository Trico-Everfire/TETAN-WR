package com.charles445.simpledifficulty.debug;

import java.lang.reflect.Method;

public class DebugScratchpad
{
	/*
	public static DebugScratchpad instance = new DebugScratchpad();
	
	public void init()
	{
		System.out.println(disableBuiltInModCompatibility("modid_goes_here"));
	}
	
	//preInit or init
	public boolean disableBuiltInModCompatibility(String modid)
	{
		try
		{
			Class SDCompatibility = Class.forName("com.charles445.simpledifficulty.api.SDCompatibility");
			Method disableBuiltInModCompatibility = SDCompatibility.getDeclaredMethod("disableBuiltInModCompatibility", String.class);
			disableBuiltInModCompatibility.invoke(null, modid);
			return true;
		}
		catch(Exception e)
		{
			return false;
		}
	}
	*/
}
