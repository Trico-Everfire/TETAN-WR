package com.charles445.simpledifficulty.api.temperature;

public class TemporaryModifier
{
	//Container for a temperature and a duration
	
	public float temperature;
	public int duration;
	
	public TemporaryModifier(float temperature, int duration)
	{
		this.temperature = temperature;
		this.duration = duration;
	}
}
