package com.charles445.simpledifficulty.config.json;

public class MaterialTemperature
{
	public String _comment = "Adding materials is not supported, this just changes Material.FIRE temperature";
	//Temperature of Material.FIRE
	public float fire = 5.0f;
}
