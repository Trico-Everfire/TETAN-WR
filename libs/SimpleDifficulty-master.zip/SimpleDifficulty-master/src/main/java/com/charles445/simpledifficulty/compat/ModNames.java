package com.charles445.simpledifficulty.compat;

public class ModNames
{
	public static final String AUW = "armorunder";
	public static final String BIOMESOPLENTY = "biomesoplenty";
	public static final String HARVESTCRAFT = "harvestcraft";
	public static final String HARVESTFESTIVAL = "harvestfestival";
	public static final String LYCANITESMOBS = "lycanitesmobs";
	public static final String OREEXCAVATION = "oreexcavation";
	public static final String PYROTECH = "pyrotech";
	public static final String REALISTICTORCHES = "realistictorches";
	public static final String RUSTIC = "rustic";
	public static final String SERENESEASONS = "sereneseasons";
	public static final String SIMPLECAMPFIRE = "campfire";
	public static final String TINKERSCONSTRUCT = "tconstruct";
}
