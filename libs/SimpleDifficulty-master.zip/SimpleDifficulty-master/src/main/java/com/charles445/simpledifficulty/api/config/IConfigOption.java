package com.charles445.simpledifficulty.api.config;

public interface IConfigOption
{
	public String getName();
}
