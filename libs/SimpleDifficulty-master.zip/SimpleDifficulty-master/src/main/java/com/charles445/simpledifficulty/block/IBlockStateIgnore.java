package com.charles445.simpledifficulty.block;

import net.minecraft.block.properties.IProperty;

public interface IBlockStateIgnore
{
	public IProperty[] getIgnoredProperties();
}
