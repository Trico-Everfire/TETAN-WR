package com.charles445.simpledifficulty.api.config.json;

public class JsonPropertyValue
{	
	public String property;
	public String value;
	
	public JsonPropertyValue(String property, String value)
	{
		this.property = property;
		this.value = value;
	}
	
}
