# SimpleDifficulty
 Difficulty mod based on Tough as Nails
