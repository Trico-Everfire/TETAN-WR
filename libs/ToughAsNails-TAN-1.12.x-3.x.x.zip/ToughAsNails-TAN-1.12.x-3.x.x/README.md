<p align="center"><img src="http://i.imgur.com/iiNg5tb.png"></p>

**Tough As Nails** is a **Minecraft mod** that adds **survival features** to increase **difficulty and realism**, including **thirst, body temperature, seasons, and more!**

-----------------

 [<img src="http://i.creativecommons.org/l/by-nc-nd/3.0/88x31.png">](http://creativecommons.org/licenses/by-nc-nd/4.0/deed.en_US)

Tough As Nails is licensed under a [Creative Commons Attribution-NonCommercial-NoDerivs 4.0 Unported License](http://creativecommons.org/licenses/by-nc-nd/4.0/deed.en_US).
