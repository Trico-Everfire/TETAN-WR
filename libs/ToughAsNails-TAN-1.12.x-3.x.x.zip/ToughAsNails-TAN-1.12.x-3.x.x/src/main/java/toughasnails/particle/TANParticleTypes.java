package toughasnails.particle;

public enum TANParticleTypes
{
    SNOWFLAKE;
}