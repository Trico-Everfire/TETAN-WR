package toughasnails.config.json;

public class MaterialTemperatureData
{
    public float fire = 5.0F;
}
