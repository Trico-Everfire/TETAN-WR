package toughasnails.api;

import net.minecraft.block.Block;
import net.minecraftforge.fluids.Fluid;

public class TANBlocks
{
    public static Block campfire;
    public static Block gas;
    public static Block temperature_coil;
    public static Block rain_collector;
    
    public static Block purified_water;
    public static Fluid purified_water_fluid;
}
