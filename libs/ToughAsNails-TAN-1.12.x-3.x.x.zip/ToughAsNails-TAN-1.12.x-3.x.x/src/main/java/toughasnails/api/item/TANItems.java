package toughasnails.api.item;

import net.minecraft.item.Item;
import net.minecraft.item.ItemArmor.ArmorMaterial;

public class TANItems
{
	public static Item tan_icon;
	
    public static Item canteen;
    public static Item fruit_juice;
    public static Item purified_water_bottle;
    public static Item thermometer;
    
    //public static Item bottle_of_gas;
    
    //public static Item respirator;
    
    public static Item wool_helmet;
    public static Item wool_chestplate;
    public static Item wool_leggings;
    public static Item wool_boots;
    public static Item jelled_slime_helmet;
    public static Item jelled_slime_chestplate;
    public static Item jelled_slime_leggings;
    public static Item jelled_slime_boots;
    
    public static Item jelled_slime;
    public static Item ice_cube;
    public static Item magma_shard;
    public static Item charcoal_filter;
    //public static Item air_filter;
    
    public static ArmorMaterial wool_armor_material;
    public static ArmorMaterial jelled_slime_armor_material;
    public static ArmorMaterial respirator_material;
}
